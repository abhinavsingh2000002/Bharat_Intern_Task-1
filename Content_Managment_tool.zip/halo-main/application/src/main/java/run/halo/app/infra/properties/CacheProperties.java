package run.halo.app.infra.properties;

import lombok.Data;

@Data
public class CacheProperties {

    private boolean disabled;

}
