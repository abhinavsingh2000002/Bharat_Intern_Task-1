package run.halo.app.event.post;

public interface PostEvent {

    String getName();

}
