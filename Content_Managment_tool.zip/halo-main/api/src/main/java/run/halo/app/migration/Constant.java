package run.halo.app.migration;

public enum Constant {
    ;

    public static final String GROUP = "migration.halo.run";

    public static final String VERSION = "v1alpha1";

    public static final String HOUSE_KEEPER_FINALIZER = "housekeeper";

}
