package run.halo.app.infra;

/**
 * @author guqing
 * @since 2.0.0
 */
public enum ConditionStatus {
    TRUE,
    FALSE,
    UNKNOWN
}
